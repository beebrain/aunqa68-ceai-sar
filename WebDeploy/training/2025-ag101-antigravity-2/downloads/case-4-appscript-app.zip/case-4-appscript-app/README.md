# 🚀 Case 4: สร้าง Application จริงด้วย Google Apps Script สั่งงานจาก Antigravity

> **เปิดโฟลเดอร์นี้ (`case-4-appscript-app/`) เป็น Workspace ใน Antigravity 2.0 แล้วทำตามใบงานได้ทันที**
> เคสนี้ต้องมี **บัญชี Google** และอินเทอร์เน็ต · แทร็ก CLASP ต้องติดตั้ง Node.js ก่อน

## 📖 สถานการณ์จำลอง
ฝ่ายบุคคลขอให้คุณทำ "ระบบลงทะเบียนอบรมออนไลน์" ที่บันทึกข้อมูลลง Google Sheets
พร้อมแดชบอร์ดสถิติ — โดยคุณ**ไม่ต้องเขียนโค้ดเองแม้แต่บรรทัดเดียว**:
คุณเป็นผู้กำหนดความต้องการ (Requirement) ส่วน Antigravity เป็นวิศวกรผู้สร้างให้

## 📂 ไฟล์ในโฟลเดอร์
| ไฟล์ | คำอธิบาย |
|---|---|
| `sample-registrations.csv` | โครงสร้างข้อมูลผู้ลงทะเบียนตัวอย่าง (5 คอลัมน์) |
| `deploy-guide.md` | คู่มือติดตั้งใช้งานจริงทีละขั้น (ทั้งแบบ Copy-Paste และแบบ CLASP) |

## 🎯 ภารกิจ

### Mission 4.1 — สั่ง Agent สร้างระบบทั้งหมด
```text
จากโครงสร้างข้อมูลในไฟล์ sample-registrations.csv ให้สร้างระบบลงทะเบียนอบรมและแดชบอร์ดดังนี้:
1. [api-handler.gs] ฟังก์ชัน doPost(e) รับข้อมูลลงทะเบียนแบบ JSON
   (ชื่อ-สกุล, อีเมล, เบอร์โทร, อาชีพ, หัวข้อที่สนใจ) บันทึกลงแถวถัดไปของ Google Sheets
   แนบ Timestamp คอลัมน์แรก ตอบกลับ JSON {status:"success"} และรองรับ CORS
2. [registration-portal.html] หน้าเว็บแบ่งสองฝั่ง:
   ฝั่งซ้ายฟอร์มลงทะเบียน ฝั่งขวาแดชบอร์ด Chart.js (กราฟแท่งตามอาชีพ + กราฟวงกลมตามหัวข้อที่สนใจ)
   มีช่องวาง Apps Script URL, ปุ่มส่งข้อมูลแบบ Fetch API ไม่รีเฟรชหน้า, Loading Spinner, Toast แจ้งผล
   ดีไซน์ Minimalist Glassmorphism โทนพาสเทลม่วง-ฟ้า ฟอนต์ Outfit + Sarabun
3. บันทึกทั้งสองไฟล์ลงในโฟลเดอร์นี้
```

### Mission 4.2 — นำขึ้นใช้งานจริง (เลือก 1 ใน 3 แทร็ก)
| แทร็ก | เหมาะกับ | วิธี |
|---|---|---|
| **A. Copy-Paste** (ง่าย ทุกคนทำได้) | ผู้เริ่มต้น | เปิด Google Sheets → Extensions → Apps Script → วางโค้ด → Deploy Web App (สิทธิ์ "Anyone") → คัดลอก URL มาวางในหน้าเว็บ — ดูขั้นละเอียดใน `deploy-guide.md` ข้อ 1–3 |
| **B. CLASP Auto-Deploy** (ขั้นสูง) | คนที่อยากเห็น Agent ปิดงานเองครบวงจร | ติดตั้ง `npm install -g @google/clasp` → `clasp login` → `clasp clone <PROJECT_ID>` แล้วสั่ง Agent ตาม Prompt ด้านล่าง — ดูขั้นละเอียดใน `deploy-guide.md` ข้อ 4 |
| **C. ทุกอย่างบน Google 100%** (ขั้นสุด) | คนที่จบแทร็ก B แล้ว | สั่ง Agent สร้างโปรเจกต์เองด้วย `clasp create` ย้ายหน้าเว็บขึ้นไปโฮสต์ใน Apps Script (HtmlService) และคุยกับชีตผ่าน `google.script.run` — ไม่เหลือไฟล์ฝั่งเครื่องเลย และไม่มีปัญหา CORS |

Prompt สำหรับแทร็ก B:
```text
เขียนโค้ดจาก api-handler.gs ลงไฟล์สคริปต์ของโปรเจกต์ CLASP ในโฟลเดอร์นี้
จากนั้นรันคำสั่ง clasp push เพื่ออัปเดตโค้ดขึ้น Google Apps Script ให้เลย
โดยไม่ต้องให้ฉันคัดลอกวางเอง เสร็จแล้วสรุปว่าต้องกด Deploy ใหม่ที่หน้าไหน
```

Prompt สำหรับแทร็ก C (ทดสอบกับ Antigravity จริงแล้ว):
```text
สร้างโปรเจกต์ Google Sheets ใหม่บนบัญชีของฉันด้วยคำสั่ง
clasp create --type sheets --title "แอปพลิเคชันลงทะเบียนอบรม" แล้วดำเนินการดังนี้:
1. ย้ายหน้าเว็บ registration-portal.html เข้าไปเป็นไฟล์ HTML ในโปรเจกต์ Apps Script
   และเพิ่มฟังก์ชัน doGet() ที่เสิร์ฟหน้านี้ด้วย HtmlService
2. เปลี่ยนการส่งข้อมูลจาก Fetch API เป็น google.script.run
   เพื่อให้หน้าเว็บคุยกับชีตผ่านระบบภายในของ Google โดยไม่ติดปัญหา CORS
3. รัน clasp push แล้ว deploy เป็น Web App (สิทธิ์ Anyone)
4. รายงานลิงก์ทั้ง 3 รายการ: Web App URL, Google Sheets และหน้า Apps Script Editor
```

สิ่งที่จะเกิดขึ้นในแทร็ก C (จากการทดลองจริง):
1. Agent รัน `clasp login` → เบราว์เซอร์เปิดหน้า OAuth ให้กดเลือกบัญชีและอนุญาตสิทธิ์
2. ถ้ายังไม่เปิด Google Apps Script API จะเจอ error — เปิดที่ script.google.com/home/usersettings แล้วบอก Agent ว่า "เรียบร้อย" ให้ทำต่อ
3. Agent สร้างชีต + สคริปต์ + deploy เอง แล้วส่งลิงก์ Web App URL กลับมา
4. เปิดหน้าเว็บจากลิงก์ script.google.com ได้เลย — หน้าเว็บถูกเสิร์ฟสดจาก Google ไม่ต้องเปิดไฟล์ในเครื่องอีกต่อไป

### ✅ ทดสอบปิดงาน
กรอกฟอร์มบนหน้าเว็บ → เห็นข้อมูล + Timestamp โผล่ใน Google Sheets = สำเร็จ 🎉

### 🌶️ ภารกิจเสริม
- สั่ง Agent เพิ่มการตรวจสอบอีเมลซ้ำ (ห้ามลงทะเบียนอีเมลเดิมสองครั้ง) ทั้งฝั่งเว็บและฝั่ง .gs
- สั่ง Agent เพิ่มปุ่ม Export รายชื่อผู้ลงทะเบียนเป็น CSV จากหน้าแดชบอร์ด

## ✅ เกณฑ์ผ่าน
1. Agent สร้าง `api-handler.gs` + `registration-portal.html` สำเร็จ
2. ลงทะเบียนผ่านหน้าเว็บแล้วข้อมูลเข้า Google Sheets จริงพร้อม Timestamp
3. (เฉพาะแทร็ก C) เปิดหน้าเว็บจาก URL ของ script.google.com ได้โดยตรง — ทุกอย่างอยู่บน Google

## 💡 บทเรียนที่ต้องการให้เห็น
เคสนี้คือภาพรวมสุดท้าย: Agent เขียนได้ทั้ง Backend (.gs) + Frontend (.html)
และถ้าใช้ CLASP ยัง Deploy เองได้ด้วย — มนุษย์ทำหน้าที่กำหนดโจทย์และตรวจรับงาน
